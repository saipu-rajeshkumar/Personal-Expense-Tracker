from django.conf import settings
from django.db import models


class Expense(models.Model):
    class Category(models.TextChoices):
        FOOD = "Food", "Food"
        TRANSPORT = "Transport", "Transport"
        RENT = "Rent", "Rent"
        BILLS = "Bills", "Bills"
        SHOPPING = "Shopping", "Shopping"
        HEALTH = "Health", "Health"
        EDUCATION = "Education", "Education"
        ENTERTAINMENT = "Entertainment", "Entertainment"
        OTHER = "Other", "Other"

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="expenses",
    )
    title = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.OTHER)
    date = models.DateField()
    description = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-date", "-created_at"]

    def __str__(self):
        return f"{self.title} — ₹{self.amount}"
