from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone
from .models import Expense


class ExpenseTrackerTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(username="testuser", password="Test-pass-12345")
        self.client.login(username="testuser", password="Test-pass-12345")

    def test_dashboard_requires_login(self):
        self.client.logout()
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 302)

    def test_user_can_add_expense(self):
        response = self.client.post(reverse("expense_create"), {
            "title": "Lunch",
            "amount": "150.00",
            "category": Expense.Category.FOOD,
            "date": timezone.localdate().isoformat(),
            "description": "Test lunch",
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Expense.objects.filter(user=self.user, title="Lunch").count(), 1)

    def test_user_cannot_edit_another_users_expense(self):
        other = get_user_model().objects.create_user(username="otheruser", password="Test-pass-12345")
        expense = Expense.objects.create(
            user=other, title="Private", amount="50.00",
            category=Expense.Category.OTHER, date=timezone.localdate(),
        )
        response = self.client.get(reverse("expense_update", args=[expense.pk]))
        self.assertEqual(response.status_code, 404)
