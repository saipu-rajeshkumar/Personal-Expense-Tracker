from decimal import Decimal
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.db.models import Sum
from django.db.models.functions import TruncMonth
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .forms import ExpenseForm
from .models import Expense


def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Your account has been created.")
            return redirect("dashboard")
    else:
        form = UserCreationForm()
    return render(request, "registration/register.html", {"form": form})


@login_required
def dashboard(request):
    expenses = Expense.objects.filter(user=request.user)
    today = timezone.localdate()
    month_expenses = expenses.filter(date__year=today.year, date__month=today.month)
    total_spent = expenses.aggregate(total=Sum("amount"))["total"] or Decimal("0.00")
    monthly_spent = month_expenses.aggregate(total=Sum("amount"))["total"] or Decimal("0.00")
    category_totals = (
        month_expenses.values("category")
        .annotate(total=Sum("amount"))
        .order_by("-total")
    )
    recent_expenses = expenses[:5]
    return render(
        request,
        "dashboard.html",
        {
            "total_spent": total_spent,
            "monthly_spent": monthly_spent,
            "expense_count": expenses.count(),
            "category_totals": category_totals,
            "recent_expenses": recent_expenses,
        },
    )


@login_required
def expense_list(request):
    expenses = Expense.objects.filter(user=request.user)
    category = request.GET.get("category", "")
    search = request.GET.get("q", "").strip()
    if category:
        expenses = expenses.filter(category=category)
    if search:
        expenses = expenses.filter(title__icontains=search)
    return render(
        request,
        "expense_list.html",
        {
            "expenses": expenses,
            "categories": Expense.Category.choices,
            "selected_category": category,
            "search_query": search,
        },
    )


@login_required
def expense_create(request):
    if request.method == "POST":
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            messages.success(request, "Expense added successfully.")
            return redirect("expense_list")
    else:
        form = ExpenseForm(initial={"date": timezone.localdate()})
    return render(request, "expense_form.html", {"form": form, "page_title": "Add expense"})


@login_required
def expense_update(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == "POST":
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, "Expense updated successfully.")
            return redirect("expense_list")
    else:
        form = ExpenseForm(instance=expense)
    return render(request, "expense_form.html", {"form": form, "page_title": "Edit expense"})


@login_required
def expense_delete(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == "POST":
        expense.delete()
        messages.success(request, "Expense deleted.")
        return redirect("expense_list")
    return render(request, "expense_confirm_delete.html", {"expense": expense})
