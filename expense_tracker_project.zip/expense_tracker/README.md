# ExpenseTracker — Personal Expense Management System

A beginner-friendly Django web application for recording, organizing, and reviewing personal expenses.

## Features

- User registration, login, and logout
- Private expenses: each user only sees their own records
- Create, view, edit, and delete expenses
- Categories, dates, amounts, and descriptions
- Search and category filtering
- Dashboard with total spending and current-month spending
- Category summary on the dashboard
- Responsive layout for desktop and mobile
- SQLite database for simple local setup

## Technology stack

- Python
- Django
- SQLite
- HTML and CSS

## Requirements

- Python 3.12 or 3.13 recommended
- pip
- VS Code (recommended)

## Run locally in VS Code

### 1. Open the project folder

Extract the ZIP file and open the `expense_tracker` folder in VS Code.

### 2. Create a virtual environment

**Windows PowerShell:**

```powershell
py -3.13 -m venv .venv
```

If Python 3.13 is not installed, use an installed supported Python version, for example `py -3.12 -m venv .venv`.

### 3. Install dependencies

This project can run without activating the virtual environment, which avoids PowerShell execution-policy issues:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### 4. Create the app migration and database tables

```powershell
.\.venv\Scripts\python.exe manage.py makemigrations expenses
.\.venv\Scripts\python.exe manage.py migrate
```

### 5. Start the development server

```powershell
.\.venv\Scripts\python.exe manage.py runserver
```

Open <http://127.0.0.1:8000/> in your browser.

### 6. Try the application

1. Select **Create account**.
2. Register with a username and password.
3. Sign in.
4. Add a few expenses from **Add expense**.
5. Review the dashboard and use the search/filter controls.

## Project structure

```text
expense_tracker/
├── manage.py
├── requirements.txt
├── README.md
├── .gitignore
├── config/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
├── expenses/
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── forms.py
│   ├── models.py
│   ├── urls.py
│   ├── views.py
│   └── migrations/
│       └── __init__.py
├── templates/
│   ├── base.html
│   ├── dashboard.html
│   ├── expense_list.html
│   ├── expense_form.html
│   ├── expense_confirm_delete.html
│   └── registration/
│       ├── login.html
│       └── register.html
└── static/
    └── css/
        └── style.css
```

## Upload to GitHub

1. Create a new empty repository on GitHub named `expense-tracker-django`.
2. Open a terminal in this project folder.
3. Run:

```bash
git init
git add .
git commit -m "Build Django expense tracker"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/expense-tracker-django.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not upload passwords, secret keys, `.env` files, or your local database.

## Resume description

**ExpenseTracker — Personal Expense Management System**  
*Python, Django, SQLite, HTML, CSS*

- Developed a web-based expense management application using Django and SQLite.
- Implemented user authentication and user-specific expense records.
- Built CRUD features for expense transactions, with category filtering and search.
- Created a dashboard summarizing total and monthly spending.

Only list features you have run and tested yourself. For a public deployment, configure production settings, a secure secret key, HTTPS, and a production-ready database/server.

## Learning outcomes

- Django project and app structure
- URL routing, views, templates, and models
- Django ORM and database migrations
- Forms, validation, authentication, and access control
- Git and GitHub workflow

## License

This project is provided for learning and portfolio use under the MIT License.
